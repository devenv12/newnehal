package Group2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created by Dev on 21/11/2016.
 */
public class DriverManager {

    private static WebDriver driver;

    public static void OpenBrowser()
    {
        DriverManager.driver = new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("http://www.sportsdirect.com/SearchResults?DescriptionFilter=nike%20shoes");
        List<WebElement> nikeShoes = (List<WebElement>) driver.findElements(By.xpath("//ul[@id='navlist']/li/div/div/a[2]/div/img"));
        List<WebElement> nikeShoesOffer = (List<WebElement>) driver.findElements(By.xpath(".//*[@id='navlist']/li/div/div/a[1]/img"));

        System.out.println("Nike Shoes without offer = "+nikeShoes.size());

        System.out.println("Nike Shoes with offer = "+nikeShoesOffer.size());
    }
}
