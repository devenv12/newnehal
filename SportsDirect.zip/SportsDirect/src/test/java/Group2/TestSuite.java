package Group2;

import org.testng.annotations.Test;

/**
 * Created by Dev on 21/11/2016.
 */
public class TestSuite extends DriverManager{

    @Test
    public static void open()
    {
    DriverManager.OpenBrowser();
    }



}

